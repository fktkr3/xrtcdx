service.LanguagePreferenceManager
=================================

A manager for audio and subtitle preferences